using UnityEngine.UIElements;
using UnityEngine;
using System.Collections.Generic;

namespace Lab5b_namespace
{
    public class Lab5b : MonoBehaviour
    {
        VisualElement plantilla;

        TextField input_nombre;
        TextField input_apellido;

        Individuo individuoPrueba;

        //top de la plantilla para poder cambiar la imagen
        VisualElement top;
        //Sprites
        VisualElement casco;
        VisualElement casco2;
        VisualElement casco3;

        //Declaraci�n de la variable backgroundSprite para poder cambiar posteriormente
        private string backgroundSprite = "casco1";
        private void OnEnable()
        {
            VisualElement root = GetComponent<UIDocument>().rootVisualElement;

            plantilla = root.Q("plantilla");
            input_nombre = root.Q<TextField>("InputNombre");
            input_apellido = root.Q<TextField>("InputApellido");

            individuoPrueba = new Individuo("Perico", "Palotes");

            Tarjeta tarjetaPrueba = new Tarjeta(plantilla, individuoPrueba);

            //Acceso al objeto top de la plantilla
            top = plantilla.Q("top");
            //Acceso a los diferentes sprites
            casco = root.Q<VisualElement>("casco");
            casco2 = root.Q<VisualElement>("casco2");
            casco3 = root.Q<VisualElement>("casco3");

            //Registro de los clics a los otros sprites de cascos
            casco.RegisterCallback<ClickEvent>(CambioACasco);
            casco2.RegisterCallback<ClickEvent>(CambioACasco2);
            casco3.RegisterCallback<ClickEvent>(CambioACasco3);
            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));

            input_nombre.RegisterCallback<ChangeEvent<string>>(CambioNombre);
            input_apellido.RegisterCallback<ChangeEvent<string>>(CambioApellido);

            input_nombre.SetValueWithoutNotify(individuoPrueba.Nombre);
            input_apellido.SetValueWithoutNotify(individuoPrueba.Apellido);
        }
        
        void CambioNombre(ChangeEvent<string> evt)
        {
            individuoPrueba.Nombre = evt.newValue;
        }
        void CambioApellido(ChangeEvent<string> evt)
        {
            individuoPrueba.Apellido = evt.newValue;
        }
        void CambioACasco(ClickEvent evt)
        {
            backgroundSprite = "casco";
            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
            Debug.Log("Sprite casco");
        }
        void CambioACasco2(ClickEvent evt)
        {
            backgroundSprite = "casco2";
            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
            Debug.Log("Sprite casco2");

        }
        void CambioACasco3(ClickEvent evt)
        {
            backgroundSprite = "casco3";
            top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
            Debug.Log("Sprite casco3");
        }
    }
}

