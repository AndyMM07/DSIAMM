using UnityEngine.UIElements;
using UnityEngine;

public class P5AndresMM : MonoBehaviour
{
    VisualElement plantilla;

    TextField input_nombre;
    TextField input_apellido;

    //Implementacion de la seleccion de imagen para el usuario
    VisualElement casco;
    VisualElement casco2;
    VisualElement casco3;
    VisualElement top;

    private string backgroundSprite = "casco1";

    private void OnEnable()
    {
        VisualElement root = GetComponent<UIDocument>().rootVisualElement;

        plantilla       = root.Q("plantilla");
        input_nombre    = root.Q<TextField>("InputNombre");
        input_apellido  = root.Q<TextField>("InputApellido");
        //Implementacion de la seleccion de imagen para el usuario
        top = plantilla.Q("top");
        casco = root.Q<VisualElement>("casco");
        casco2 = root.Q<VisualElement>("casco2");
        casco3 = root.Q<VisualElement>("casco3");

        plantilla.RegisterCallback<ClickEvent>(SeleccionIndividuo);
        input_nombre.RegisterCallback<ChangeEvent<string>>(CambioNombre);
        input_apellido.RegisterCallback<ChangeEvent<string>>(CambioApellido);
        casco.RegisterCallback<ClickEvent>(CambioACasco);
        casco2.RegisterCallback<ClickEvent>(CambioACasco2);
        casco3.RegisterCallback<ClickEvent>(CambioACasco3);
        top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
    }
    void SeleccionIndividuo(ClickEvent evt)
    {
        string nombre   = plantilla.Q<Label>("Nombre").text; 
        string apellido = plantilla.Q<Label>("Apellido").text;

        Debug.Log(nombre);

        input_nombre.SetValueWithoutNotify(nombre); 
        input_apellido.SetValueWithoutNotify(apellido);
    }
    void CambioNombre(ChangeEvent<string> evt) 
    {
        Label nombreLabel   = plantilla.Q<Label>("Nombre");
        nombreLabel.text    = evt.newValue;
    }
    void CambioApellido(ChangeEvent<string> evt)
    {
        Label apellidoLabel = plantilla.Q<Label>("Apellido");
        apellidoLabel.text  = evt.newValue;
    }
    //Seleccion imagenes
    void CambioACasco(ClickEvent evt)
    {
        backgroundSprite = "casco";
        top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
        Debug.Log("Sprite casco");
    }
    void CambioACasco2(ClickEvent evt)
    {
        backgroundSprite = "casco2";
        top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
        Debug.Log("Sprite casco2");

    }
    void CambioACasco3(ClickEvent evt)
    {
        backgroundSprite = "casco3";
        top.style.backgroundImage = new StyleBackground(Resources.Load<Sprite>(backgroundSprite));
        Debug.Log("Sprite casco3");
    }
}
