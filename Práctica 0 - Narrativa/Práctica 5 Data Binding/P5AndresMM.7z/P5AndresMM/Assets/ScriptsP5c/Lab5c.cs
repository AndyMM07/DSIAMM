using UnityEngine.UIElements;
using UnityEngine;
using System.Collections.Generic;

namespace Lab5b_namespace
{
    public class Lab5c : MonoBehaviour
    {
        List<Individuo> individuos;
        Individuo selecIndividuo;

        VisualElement tarjeta1;
        VisualElement tarjeta2;
        VisualElement tarjeta3;
        VisualElement tarjeta4;
        //Creacion de variable accesible para poder utilizar en el cambio de imagenes
        VisualElement tarjetaSelect;

        VisualElement individuoElegido;

        TextField input_nombre;
        TextField input_apellido;

        private void OnEnable()
        {
            VisualElement root = GetComponent<UIDocument>().rootVisualElement;

            tarjeta1 = root.Q("Tarjeta1");
            tarjeta2 = root.Q("Tarjeta2");
            tarjeta3 = root.Q("Tarjeta3");
            tarjeta4 = root.Q("Tarjeta4");

            input_nombre = root.Q<TextField>("InputNombre");
            input_apellido = root.Q<TextField>("InputApellido");

            individuos = Basedatos.getData();

            //Acceso a los hijos del header (las imagenes a poder clicar para cambiar por las de las tarjetas)
            VisualElement header = root.Q("header");

            header.Children();
            foreach (VisualElement images in header.Children())
            {
                images.RegisterCallback<ClickEvent>(CambioImagen);
            }

            VisualElement panelDcha = root.Q("Dcha");
            panelDcha.RegisterCallback<ClickEvent>(seleccionTarjeta);

            input_nombre.RegisterCallback<ChangeEvent<string>>(CambioNombre);
            input_apellido.RegisterCallback<ChangeEvent<string>>(CambioApellido);

            InitializeUI();
        }
        void CambioNombre(ChangeEvent<string> evt)
        {
            selecIndividuo.Nombre = evt.newValue;
        }
        void CambioApellido(ChangeEvent<string> evt)
        {
            selecIndividuo.Apellido = evt.newValue;
        }
        void seleccionTarjeta(ClickEvent e)
        {
            VisualElement tarjeta = e.target as VisualElement;
            selecIndividuo = tarjeta.userData as Individuo;
            //Permitimos el acceso al elemento clicado para posteriormente poder cambiar la imagen
            tarjetaSelect = e.target as VisualElement;

            input_nombre.SetValueWithoutNotify(selecIndividuo.Nombre);
            input_apellido.SetValueWithoutNotify(selecIndividuo.Apellido);
        }
        void InitializeUI()
        {
            Tarjeta tar1 = new Tarjeta(tarjeta1, individuos[0]);
            Tarjeta tar2 = new Tarjeta(tarjeta2, individuos[1]);
            Tarjeta tar3 = new Tarjeta(tarjeta3, individuos[2]);
            Tarjeta tar4 = new Tarjeta(tarjeta4, individuos[3]);
        }
        void CambioImagen(ClickEvent e)
        {
            VisualElement image = tarjetaSelect.Q<VisualElement>("top");

            VisualElement headerChild = e.target as VisualElement;
            image.style.backgroundImage = headerChild.resolvedStyle.backgroundImage;
        }
    }
}

