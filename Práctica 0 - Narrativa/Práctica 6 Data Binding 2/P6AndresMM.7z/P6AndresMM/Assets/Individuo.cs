using UnityEngine;
using System;

namespace Lab6_namespace      
{
    public class Individuo
    {
        public event Action Cambio;

        //A la hora de la implementaci�n de paso de datos al Json, no es posible acceder al string nombre, ni apellido, en caso de ser privados
        //me veo forzado al cambio de privacidad de las variables
        public string nombre;

        public string Nombre
        {
            get { return nombre; }
            set
            {
                if (value != nombre)
                {
                    nombre = value;
                    Cambio?.Invoke();
                }
            }
        }

        public string apellido;

        public string Apellido
        {
            get { return apellido; }
            set
            {
                if (value != apellido)
                {
                    apellido = value;
                    Cambio?.Invoke();
                }
            }
        }
        public Individuo(string nombre, string apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }
    }
}
